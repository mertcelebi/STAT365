# Problem Set 01 starter code
#
# Please make sure your code runs on R version 3.2.2
# Due date: 2016-02-05 13:00
# By: Feridun Mert Celebi (fmc27)

#' Basic k-nearest neighbor functionality
#'
#' k-nearest neighbor regression for a numeric test
#' matrix. Prediction are returned for the same data matrix
#' used for training. For each row of the input, the k
#' closest rows (using the l2 distance) in the training
#' set are identified. The mean of the observations y
#' is used for the predicted value of a new observation.
#'
#' @param X     an n by p numeric matrix; the data
#'                matrix of predictors
#' @param y     a length n numeric vector; the observed
#'                response
#' @param k     integer giving the number of neighbors to
#'                include
#'
#' @return      a vector of predicted responses for each row
#'                of the input matrix X
my_knn <- function (X, y, k = 1L) {
  n_rows <- nrow(X)
  predictions <- rep(NA, n_rows)

  for (index in 1 : n_rows) {
    predictions[index] <- get_knn(X[index, ], X, y, k)
  }

  return (predictions)
}

# Finds k-nn rows using l2 distance and returns the corresponding mean y values.
get_knn <- function (row, rest, y, k) {
  n_rows <- nrow(rest)
  distances <- rep(NA, n_rows)

  for (index in 1 : n_rows) {
    distances[index] <- dist(rbind(row, rest[index, ]))[1]
  }

  return (mean(y[head(sort.int(distances, index.return = TRUE)$ix, k)]))
}

#' Kernel smoothing function
#'
#' kernel smoother for a numeric test matrix with a Gaussian
#' kernel. Predictions are returned for the same data matrix
#' used for training. For each row of the input, a weighted
#' average of the input y is used for prediction. The weights
#' are given by the density of the normal distribution for
#' the distance of a point to the input.
#'
#' @param X       an n by p numeric matrix; the data
#'                  matrix of predictors
#' @param y       a length n numeric vector; the observed
#'                  response
#' @param sigma   the standard deviation of the normal density
#'                  function used for the weighting scheme
#'
#' @return        a vector of predicted responses for each row
#'                  of the input matrix Xnew
my_ksmooth <- function(X, y, sigma = 1.0) {
  n_rows <- nrow(X)
  predictions <- rep(NA, n_rows)

  for (index in 1 : n_rows) {
    predictions[index] <- get_ksmooth(X[index, ], X, y, sigma)
  }

  return (predictions)
}

# Finds the prediction for the given row after calculating the weight of the other rows.
get_ksmooth <- function (row, rest, y, sigma) {
  n_rows <- nrow(rest)
  prediction <- 0
  weights <- 0

  for (index in 1 : n_rows) {
    distance <- dist(rbind(row, rest[index, ]), method = "euclidian")[1]
    distance <- distance ^ 2

    # Gives the Gaussian density function
    weight <- dnorm(distance, sd = sigma)
    weights <- weights + weight
    prediction <- prediction + (y[index] * weight)
  }

  return (prediction / weights)
}
